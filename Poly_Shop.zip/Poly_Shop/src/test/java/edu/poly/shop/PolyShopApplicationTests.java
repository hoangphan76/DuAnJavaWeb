package edu.poly.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolyShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
