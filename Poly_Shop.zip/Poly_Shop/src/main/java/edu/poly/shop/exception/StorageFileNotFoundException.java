package edu.poly.shop.exception;

public class StorageFileNotFoundException extends StorageException{

	public StorageFileNotFoundException(String message) {
		super(message);
		
	}


}
