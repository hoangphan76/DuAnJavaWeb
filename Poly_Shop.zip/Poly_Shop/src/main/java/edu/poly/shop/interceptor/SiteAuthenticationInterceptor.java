package edu.poly.shop.interceptor;

public class SiteAuthenticationInterceptor {

}
